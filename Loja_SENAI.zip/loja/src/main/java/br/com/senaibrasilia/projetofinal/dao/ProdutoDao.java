package br.com.senaibrasilia.projetofinal.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;

import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;
import br.com.senaibrasilia.projetofinal.util.JPAUtil;

public class ProdutoDao {
	private  EntityManager em;
	public ProdutoDao(EntityManager em) {
		this.em=em;
	}
		
	public void cadastrar(Produto prouto) {
		this.em.persist(prouto);
		//persist
	}
	public void atualizar(Produto produto) {
		this.em.merge(produto);
	// merge	
	}
	public void remover(Produto produto) {
		produto= em.merge(produto);
		this.em.remove(produto);
	}
	public Produto pesquisarPorCodigo(long id) {
	 return this.em.find(Produto.class, id);
	}
	public void pesquisarPorNome(String nome) {
		this.em.find(Categoria.class,nome);
		
	}
	public Produto buscarPorId(long id) {
		return em.find(Produto.class, id);
	}
	
	
	public List<Produto> buscarPorTodos() {
		
		String jpql= "SELECT p FROM Produto p";
		return em.createQuery(jpql, Produto.class)		
				.getResultList();
		//query- JPQL
		//aRRAY LIST
		//lambda-java8
		//public void remover() 
		}

	public  List<Produto> buscarPorNomeDaCategoria(String nome) {
		
		String jpql= "SELECT p FROM Produto p WHERE p.categoria.nome= :nome";
		return em.createQuery(jpql, Produto.class)
				.setParameter("nome",nome)
				.getResultList();}

	public List<Produto> buscarPrecoDoProdutoComNome(BigDecimal preco) {
		String jpql= "SELECT p FROM Produto p WHERE p.categoria.nome= :nome";
		return em.createQuery(jpql, Produto.class).setParameter("preco",preco).getResultList();
		}

	
}
